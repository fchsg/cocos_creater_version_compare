System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/meshopt_decoder.wasm-12c0a404.wasm")}}}));
