System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/bullet-7a2167c6.wasm")}}}));
